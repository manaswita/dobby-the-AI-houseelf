import React from 'react';
import { Database, Bell, User, LogOut, Sparkles, RefreshCw, MessageSquare, Download } from 'lucide-react';
import { UserProfile, SystemHealth } from '../types';

interface HeaderProps {
  user: UserProfile | null;
  health: SystemHealth | null;
  unreadCount: number;
  onOpenAuth: () => void;
  onLogout: () => void;
  onOpenDbStatus: () => void;
  onOpenNotifications: () => void;
  onOpenAlertSettings?: () => void;
  refreshHealth: () => void;
  onTestConnect?: () => void;
  isTestingDb?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  user,
  health,
  unreadCount,
  onOpenAuth,
  onLogout,
  onOpenDbStatus,
  onOpenNotifications,
  onOpenAlertSettings,
  refreshHealth,
  onTestConnect,
  isTestingDb = false,
}) => {
  const isMongo = health?.database?.connectedToMongoDB;

  return (
    <header className="border-b border-slate-800 bg-slate-950/80 backdrop-blur-md sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand & Identity */}
        <div className="flex items-center gap-3">
          <div className="relative w-10 h-10 rounded-xl bg-gradient-to-tr from-slate-900 via-slate-800 to-indigo-950 border border-cyan-500/40 flex items-center justify-center font-bold text-cyan-300 shadow-md shadow-cyan-500/20 text-lg font-cinzel tracking-tight group overflow-hidden">
            <span className="relative z-10 text-xl font-bold bg-gradient-to-b from-cyan-200 via-slate-100 to-cyan-400 bg-clip-text text-transparent">
              𝔇
            </span>
            <div className="absolute inset-0 bg-cyan-400/10 rounded-xl blur-sm" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-cinzel font-bold text-slate-100 tracking-wider text-base sm:text-lg">
                Dobby
              </span>
              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/25">
                The House Help
              </span>
              <span className="hidden md:inline-block text-[10px] uppercase font-semibold tracking-wider px-1.5 py-0.5 rounded-md bg-slate-800/80 text-slate-400 border border-slate-700/60">
                Node + MongoDB
              </span>
            </div>
            <p className="text-[11px] text-slate-400 hidden sm:flex items-center gap-1">
              <span>Your Faithful Household Assistant</span>
              <span className="text-cyan-500/60">•</span>
              <span className="text-slate-500 italic">Always at your service</span>
            </p>
          </div>
        </div>

        {/* Database Status Pill & Actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* If MongoDB Atlas is not yet connected, show the explicit Test & Connect button */}
          {!isMongo && onTestConnect && (
            <button
              id="btn-header-test-connect"
              onClick={onTestConnect}
              disabled={isTestingDb}
              title="Click to test & connect to live MongoDB Atlas"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-cyan-500 hover:bg-cyan-400 text-slate-950 transition-all shadow-sm shadow-cyan-500/20 disabled:opacity-60"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isTestingDb ? 'animate-spin' : ''}`} />
              <span className="hidden sm:inline">Test &amp; Connect MongoDB</span>
              <span className="sm:hidden">Test DB</span>
            </button>
          )}

          <button
            id="btn-db-status"
            onClick={onOpenDbStatus}
            title="Click to view database connection details & diagnostics"
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
              isMongo
                ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-300 hover:bg-emerald-900/40'
                : health?.database?.mongoUriProvided
                ? 'bg-amber-950/30 border-amber-500/30 text-amber-300 hover:bg-amber-900/30'
                : 'bg-slate-900 border-slate-700 text-cyan-300 hover:bg-slate-800'
            }`}
          >
            <Database className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden md:inline">
              {isMongo
                ? 'MongoDB Atlas (Live)'
                : health?.database?.mongoUriProvided
                ? 'Atlas: Check Whitelist'
                : 'MongoDB Document Store'}
            </span>
            <span className="md:hidden">DB Status</span>
            <span
              className={`w-2 h-2 rounded-full ${
                isMongo
                  ? 'bg-emerald-400 shadow-sm shadow-emerald-400/80'
                  : health?.database?.mongoUriProvided
                  ? 'bg-amber-400 shadow-sm shadow-amber-400/80 animate-pulse'
                  : 'bg-emerald-400'
              }`}
            ></span>
          </button>

          {/* WhatsApp Alerts button */}
          {user && onOpenAlertSettings && (
            <button
              id="btn-whatsapp-alerts"
              onClick={onOpenAlertSettings}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 hover:bg-emerald-900/40 hover:border-emerald-500/50 transition-all shadow-sm"
              title="Configure WhatsApp Alerts & Reminders"
            >
              <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden sm:inline text-[11px] font-bold">WhatsApp Alerts</span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse hidden sm:inline-block"></span>
            </button>
          )}

          {/* Download Project ZIP button */}
          <a
            id="btn-download-project-zip"
            href="/api/download-project-zip"
            download="dobby-house-help.zip"
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-indigo-950/40 border border-indigo-500/30 text-indigo-300 hover:bg-indigo-900/40 hover:border-indigo-500/50 transition-all shadow-sm"
            title="Download full project code as ZIP to transfer to another account"
          >
            <Download className="w-3.5 h-3.5 text-indigo-400" />
            <span className="hidden sm:inline text-[11px] font-bold">Export ZIP</span>
          </a>

          {/* Notifications button */}
          {user && (
            <button
              id="btn-notifications"
              onClick={onOpenNotifications}
              className="relative p-2 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-900 transition-colors"
              title="Notifications"
            >
              <Bell className="w-5 h-5" />
              {unreadCount > 0 && (
                <span className="absolute top-1.5 right-1.5 w-4 h-4 rounded-full bg-rose-500 text-white text-[10px] font-bold flex items-center justify-center">
                  {unreadCount > 9 ? '9+' : unreadCount}
                </span>
              )}
            </button>
          )}

          {/* User Account / Sign in */}
          {user ? (
            <div className="flex items-center gap-2 pl-2 border-l border-slate-800">
              <div className="hidden sm:block text-right">
                <div className="text-xs font-bold text-slate-200">{user.name}</div>
                <div className="text-[11px] text-slate-400 truncate max-w-[140px]">{user.email}</div>
              </div>
              <button
                id="btn-logout"
                onClick={onLogout}
                className="p-2 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-950/20 transition-colors"
                title="Sign out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button
              id="btn-signin-header"
              onClick={onOpenAuth}
              className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold transition-all shadow-sm shadow-cyan-500/20"
            >
              <User className="w-3.5 h-3.5" />
              <span>Sign In / Register</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};

import React, { useState, useEffect, useCallback } from 'react';
import {
  Sparkles,
  CheckCircle2,
  Clock,
  Users,
  Terminal,
  Database,
  RefreshCw,
  Plus,
  Layers,
  Calendar,
  ShieldCheck,
  Zap,
  AlertCircle,
  Mail,
  MessageSquare,
} from 'lucide-react';
import { api } from './api';
import {
  UserProfile,
  Task,
  Group,
  Reminder,
  NotificationItem,
  SystemHealth,
} from './types';
import { Header } from './components/Header';
import { AuthModal } from './components/AuthModal';
import { AiIngestCard } from './components/AiIngestCard';
import { TaskList } from './components/TaskList';
import { RemindersList } from './components/RemindersList';
import { GroupManager } from './components/GroupManager';
import { NotificationsDrawer } from './components/NotificationsDrawer';
import { DbStatusModal } from './components/DbStatusModal';
import { ApiConsole } from './components/ApiConsole';
import { NotificationChannelsModal } from './components/NotificationChannelsModal';

export default function App() {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [groups, setGroups] = useState<Group[]>([]);
  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [users, setUsers] = useState<Array<{ _id: string; name: string }>>([]);
  const [health, setHealth] = useState<SystemHealth | null>(null);

  const [activeTab, setActiveTab] = useState<'tasks' | 'reminders' | 'groups' | 'api'>('tasks');
  const [selectedGroupId, setSelectedGroupId] = useState<string>('');

  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isDbStatusOpen, setIsDbStatusOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isChannelsModalOpen, setIsChannelsModalOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [reconnectingDb, setReconnectingDb] = useState(false);
  const [reconnectResult, setReconnectResult] = useState<{ success: boolean; message: string } | null>(null);

  // Load system health
  const loadHealth = useCallback(async () => {
    try {
      const data = await api.getHealth();
      setHealth(data);
    } catch (e) {
      console.warn('Could not load health:', e);
    }
  }, []);

  // Load user data
  const loadUserData = useCallback(async () => {
    try {
      const [tasksRes, groupsRes, remindersRes, notifsRes, usersRes] = await Promise.all([
        api.getTasks().catch(() => ({ tasks: [] })),
        api.getGroups().catch(() => ({ groups: [] })),
        api.getReminders().catch(() => ({ reminders: [] })),
        api.getNotifications().catch(() => ({ notifications: [] })),
        api.getUsers().catch(() => ({ users: [] })),
      ]);

      setTasks(tasksRes.tasks || []);
      setGroups(groupsRes.groups || []);
      setReminders(remindersRes.reminders || []);
      setNotifications(notifsRes.notifications || []);
      setUsers(usersRes.users || []);

      if (groupsRes.groups && groupsRes.groups.length > 0 && !selectedGroupId) {
        setSelectedGroupId(groupsRes.groups[0]._id);
      }
    } catch (err) {
      console.error('Error loading data:', err);
    }
  }, [selectedGroupId]);

  const handleReconnectDb = async () => {
    setReconnectingDb(true);
    setReconnectResult(null);
    try {
      const res = await api.reconnectDb();
      setReconnectResult({
        success: res.connectedToMongoDB,
        message: res.message,
      });
      await loadHealth();
      await loadUserData();
    } catch (err: any) {
      setReconnectResult({
        success: false,
        message: err?.message || 'Failed to connect to MongoDB',
      });
    } finally {
      setReconnectingDb(false);
    }
  };

  // Initial bootstrap: check existing token, or auto-login with pre-seeded demo user
  useEffect(() => {
    const init = async () => {
      setLoading(true);
      await loadHealth();

      const existingToken = api.getToken();
      if (existingToken) {
        try {
          const res = await api.getMe();
          setCurrentUser(res.user);
          await loadUserData();
          setLoading(false);
          return;
        } catch {
          api.clearToken();
        }
      }

      // Auto-login with default seeded demo user (Alex Rivera) for zero friction preview
      try {
        const loginRes = await api.login('alex@tasklens.io', 'password123');
        api.setToken(loginRes.token);
        setCurrentUser(loginRes.user);
        await loadUserData();
      } catch (e) {
        console.log('No active session; user can sign in via modal');
      } finally {
        setLoading(false);
      }
    };

    init();
  }, [loadHealth, loadUserData]);

  const handleLogout = () => {
    api.clearToken();
    setCurrentUser(null);
    setTasks([]);
    setGroups([]);
    setReminders([]);
    setNotifications([]);
  };

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-slate-950">
      {/* Top Header */}
      <Header
        user={currentUser}
        health={health}
        unreadCount={unreadCount}
        onOpenAuth={() => setIsAuthOpen(true)}
        onLogout={handleLogout}
        onOpenDbStatus={() => setIsDbStatusOpen(true)}
        onOpenNotifications={() => setIsNotificationsOpen(true)}
        onOpenAlertSettings={() => setIsChannelsModalOpen(true)}
        refreshHealth={loadHealth}
        onTestConnect={handleReconnectDb}
        isTestingDb={reconnectingDb}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Prominent MongoDB Atlas Connection Banner if not yet connected to live Atlas */}
        {!health?.database?.connectedToMongoDB && (
          <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-amber-950/40 via-slate-900 to-slate-900 border-2 border-amber-500/40 shadow-xl space-y-3">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex items-start gap-3">
                <div className="p-2.5 rounded-xl bg-amber-500/15 text-amber-400 border border-amber-500/30 shrink-0 mt-0.5">
                  <Database className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <span className="text-xs font-black uppercase tracking-wider px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                      MongoDB Atlas Detected
                    </span>
                    <span className="text-xs text-slate-400">
                      Active Mode: <strong className="text-cyan-400">{health?.database?.mode || 'Local Store (MongoDB Emulation)'}</strong>
                    </span>
                  </div>
                  <h2 className="text-sm sm:text-base font-bold text-slate-100">
                    Connect Live MongoDB Atlas Cluster
                  </h2>
                  <p className="text-xs text-slate-300 max-w-2xl mt-0.5">
                    {health?.database?.error?.includes('whitelist')
                      ? 'Atlas Network Access whitelist required: add 0.0.0.0/0 in Atlas to allow connection from cloud containers.'
                      : 'Test and establish connection to your live MongoDB Atlas cluster.'}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2.5 shrink-0 flex-wrap">
                <button
                  id="btn-main-test-connect"
                  onClick={handleReconnectDb}
                  disabled={reconnectingDb}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-black transition-all shadow-lg shadow-cyan-500/25 disabled:opacity-50"
                >
                  <RefreshCw className={`w-4 h-4 ${reconnectingDb ? 'animate-spin' : ''}`} />
                  <span>{reconnectingDb ? 'Testing Connection...' : 'Test & Connect MongoDB'}</span>
                </button>
                <button
                  id="btn-main-view-whitelist-instructions"
                  onClick={() => setIsDbStatusOpen(true)}
                  className="px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 transition-colors"
                >
                  Whitelist Guide
                </button>
              </div>
            </div>

            {reconnectResult && (
              <div
                className={`p-3 rounded-xl text-xs flex items-center gap-2 ${
                  reconnectResult.success
                    ? 'bg-emerald-950/60 border border-emerald-500/40 text-emerald-300'
                    : 'bg-rose-950/60 border border-rose-500/40 text-rose-300'
                }`}
              >
                {reconnectResult.success ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                )}
                <span>{reconnectResult.message}</span>
              </div>
            )}
          </div>
        )}

        {health?.database?.connectedToMongoDB && (
          <div className="px-4 py-3 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 flex items-center justify-between text-xs text-emerald-300">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>
                <strong>Live MongoDB Atlas Connected!</strong> Mongoose schemas and collections are actively reading and writing to your Atlas cluster.
              </span>
            </div>
            <button
              onClick={() => setIsDbStatusOpen(true)}
              className="text-xs text-emerald-400 underline font-semibold hover:text-emerald-300 shrink-0 ml-2"
            >
              View Record Inventory
            </button>
          </div>
        )}
        {/* Backend Overview Banner */}
        <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900 to-slate-950 border border-slate-800 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/25">
                Node.js + MongoDB Basin
              </span>
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-slate-800/80 text-slate-300 border border-slate-700/60">
                Mongoose 8.23 Models
              </span>
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-slate-800/80 text-slate-300 border border-slate-700/60">
                JWT Auth Wards
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold font-cinzel text-slate-100 tracking-wide">
              Dobby — The House Help
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 max-w-3xl">
              Hand over letters, bills, permission slips, school forms, WhatsApp chats, or notes to Dobby. Dobby extracts every commitment, organizes the household, and schedules your reminders!
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <div className="text-right hidden sm:block">
              <div className="text-xs font-bold text-slate-300">
                {tasks.filter((t) => t.status !== 'completed').length} Active Commitments
              </div>
              <div className="text-[11px] text-cyan-400">
                {reminders.filter((r) => r.status === 'scheduled').length} Scheduled Remembralls
              </div>
            </div>

            <button
              onClick={() => {
                loadHealth();
                loadUserData();
              }}
              className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-cyan-300 transition-colors"
              title="Refresh basin records"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* AI Task Extraction Ingestion Engine */}
        <AiIngestCard
          groups={groups}
          selectedGroupId={selectedGroupId}
          onTasksCreated={() => {
            loadUserData();
            loadHealth();
          }}
        />

        {/* Navigation Tabs */}
        <div className="border-b border-slate-800 flex items-center justify-between gap-2 sm:gap-4 overflow-x-auto pb-1 text-sm font-semibold">
          <div className="flex items-center gap-2 sm:gap-4 shrink-0">
            <button
              onClick={() => setActiveTab('tasks')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl transition-all whitespace-nowrap ${
                activeTab === 'tasks'
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Tasks &amp; To-Dos</span>
              <span
                className={`text-xs px-1.5 py-0.2 rounded-full font-bold ${
                  activeTab === 'tasks' ? 'bg-slate-950 text-cyan-400' : 'bg-slate-800 text-slate-300'
                }`}
              >
                {tasks.length}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('reminders')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl transition-all whitespace-nowrap ${
                activeTab === 'reminders'
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <Clock className="w-4 h-4" />
              <span>Reminders &amp; Alerts</span>
              <span
                className={`text-xs px-1.5 py-0.2 rounded-full font-bold ${
                  activeTab === 'reminders' ? 'bg-slate-950 text-cyan-400' : 'bg-slate-800 text-slate-300'
                }`}
              >
                {reminders.filter((r) => r.status !== 'dismissed').length}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('groups')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl transition-all whitespace-nowrap ${
                activeTab === 'groups'
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>Family &amp; Households</span>
              <span
                className={`text-xs px-1.5 py-0.2 rounded-full font-bold ${
                  activeTab === 'groups' ? 'bg-slate-950 text-cyan-400' : 'bg-slate-800 text-slate-300'
                }`}
              >
                {groups.length}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('api')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl transition-all whitespace-nowrap ${
                activeTab === 'api'
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <Terminal className="w-4 h-4" />
              <span>API Console</span>
            </button>
          </div>

          {/* Alert Channels Direct Access */}
          <button
            id="tab-alert-channels-modal-btn"
            onClick={() => setIsChannelsModalOpen(true)}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-850 border border-cyan-500/30 text-cyan-300 text-xs font-bold shrink-0 transition-all shadow-sm shadow-cyan-950/40 ml-2"
            title="Configure Email Alerts and WhatsApp Notifications"
          >
            <span className="flex items-center -space-x-1">
              <Mail className="w-3.5 h-3.5 text-cyan-400" />
              <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
            </span>
            <span className="hidden sm:inline">Alert Channels:</span>
            <span className="text-slate-200">Email &amp; WhatsApp</span>
          </button>
        </div>

        {/* Tab Contents */}
        {activeTab === 'tasks' && (
          <TaskList
            tasks={tasks}
            groups={groups}
            users={users}
            currentUser={currentUser}
            onRefresh={() => {
              loadUserData();
              loadHealth();
            }}
          />
        )}

        {activeTab === 'reminders' && (
          <RemindersList
            reminders={reminders}
            currentUser={currentUser}
            onOpenAlertSettings={() => setIsChannelsModalOpen(true)}
            onRefresh={() => {
              loadUserData();
              loadHealth();
            }}
          />
        )}

        {activeTab === 'groups' && (
          <GroupManager
            groups={groups}
            currentUser={currentUser}
            onRefresh={() => {
              loadUserData();
              loadHealth();
            }}
          />
        )}

        {activeTab === 'api' && <ApiConsole />}
      </main>

      {/* Modals & Drawers */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onSuccess={(user) => {
          setCurrentUser(user);
          loadUserData();
          loadHealth();
        }}
      />

      <DbStatusModal
        isOpen={isDbStatusOpen}
        onClose={() => setIsDbStatusOpen(false)}
        health={health}
        onRefresh={() => {
          loadHealth();
          loadUserData();
        }}
      />

      <NotificationsDrawer
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
        notifications={notifications}
        onRefresh={loadUserData}
        onOpenAlertSettings={() => setIsChannelsModalOpen(true)}
      />

      <NotificationChannelsModal
        isOpen={isChannelsModalOpen}
        onClose={() => setIsChannelsModalOpen(false)}
        currentUser={currentUser}
        onUserUpdated={(updated) => setCurrentUser(updated)}
      />
    </div>
  );
}
